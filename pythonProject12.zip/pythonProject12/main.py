import requests
import re
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import webbrowser
import sys


# Функция для отправки уязвимостей в GPT для подробного анализа
def explain_vulnerabilities_to_gpt(vulnerabilities):
    explanation = "Here are the detailed vulnerabilities found on the website:\n\n"
    for url, vulns in vulnerabilities.items():
        explanation += f"URL: {url}\n"
        for vulnerability, attack_method in vulns.items():
            explanation += f"Vulnerability: {vulnerability}\n"
            explanation += f"Attack Method: {attack_method}\n"
            explanation += f"Explanation: {explain_vulnerability(vulnerability)}\n"
        explanation += "\n"
    return explanation


# Пример функции объяснения уязвимостей
def explain_vulnerability(vulnerability):
    explanations = {
        "SQL injection vulnerability": (
            "SQL injection allows an attacker to interfere with the queries that an application makes to its database. "
            "By inserting or 'injecting' SQL code into user inputs, an attacker may view or modify data in the database, "
            "potentially bypassing security controls."
        ),
        "Cross-site scripting (XSS) vulnerability": (
            "Cross-site scripting (XSS) allows an attacker to inject malicious scripts into web pages viewed by other users. "
            "These scripts can steal information, impersonate the user, or perform malicious actions on the user's behalf."
        ),
        "Insecure server configuration": (
            "Insecure server configurations include vulnerabilities like using HTTP instead of HTTPS or using weak encryption "
            "methods. These issues can allow attackers to intercept sensitive data, modify communications, or exploit weaknesses."
        )
    }
    return explanations.get(vulnerability, "No detailed explanation available.")


def scan_website(url):
    # Словарь для хранения уязвимостей
    all_vulnerabilities = {}

    # Step 1: Discover URLs on the website
    discovered_urls = discover_urls(url)
    print(f"Discovered {len(discovered_urls)} URLs on {url}:\n")
    for i, discovered_url in enumerate(discovered_urls, start=1):
        print(f"{i}. {discovered_url}")

    # Step 2: Scan discovered URLs for vulnerabilities
    print("\nStarting vulnerability scan...\n")
    for page_url in discovered_urls:
        vulnerabilities = scan_url(page_url)
        if vulnerabilities:
            print(f"\nVulnerabilities found on {page_url}:")
            for vulnerability, attack_method in vulnerabilities.items():
                print(f"\nVulnerability: {vulnerability}")
                print(f"Attack Method: {attack_method}")
            all_vulnerabilities[page_url] = vulnerabilities
        else:
            print(f"No vulnerabilities found on {page_url}.\n")

    # После сканирования отправляем данные в GPT для получения подробного отчета
    detailed_report = explain_vulnerabilities_to_gpt(all_vulnerabilities)
    print("\n--- Detailed Vulnerability Report ---\n")
    print(detailed_report)


def discover_urls(url):
    discovered_urls = []

    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an error for bad responses (4xx or 5xx)
    except requests.exceptions.RequestException as e:
        print(f"Error fetching the URL: {e}")
        return discovered_urls  # Return an empty list on error

    # Parse the HTML content of the response
    soup = BeautifulSoup(response.text, "html.parser")
    # Find all anchor tags and extract URLs
    for anchor_tag in soup.find_all("a"):
        href = anchor_tag.get("href")
        if href:
            absolute_url = urljoin(url, href)
            discovered_urls.append(absolute_url)

    return discovered_urls


def scan_url(url):
    vulnerabilities = {}

    # Step 1: Perform vulnerability scans using a vulnerability scanner or custom checks

    # Example: Check for SQL injection vulnerability
    if is_sql_injection_vulnerable(url):
        vulnerabilities["SQL injection vulnerability"] = "Injecting SQL code into input fields"

    # Example: Check for cross-site scripting (XSS) vulnerability
    if is_xss_vulnerable(url):
        vulnerabilities["Cross-site scripting (XSS) vulnerability"] = "Injecting malicious scripts into input fields"

    # Step 2: Perform additional vulnerability checks or manual code review

    # Example: Check for insecure server configuration
    if has_insecure_configuration(url):
        vulnerabilities["Insecure server configuration"] = "Exploiting insecure communication protocols"

    return vulnerabilities


def is_sql_injection_vulnerable(url):
    # Perform checks for SQL injection vulnerability
    # Example: Send a malicious SQL query and check the response
    payload = "' OR '1'='1"
    try:
        response = requests.get(url + "?id=" + payload)
        if re.search(r"error|warning", response.text, re.IGNORECASE):
            return True
    except requests.exceptions.RequestException as e:
        print(f"Error testing SQL injection on {url}: {e}")
    return False


def is_xss_vulnerable(url):
    # Perform checks for cross-site scripting (XSS) vulnerability
    # Example: Inject a script tag and check if it gets executed
    payload = "<script>alert('XSS')</script>"
    try:
        response = requests.get(url + "?input=" + payload)
        if payload in response.text:
            return True
    except requests.exceptions.RequestException as e:
        print(f"Error testing XSS on {url}: {e}")
    return False


def has_insecure_configuration(url):
    # Perform checks for insecure server configuration
    # Example: Check if the website uses HTTP instead of HTTPS
    if not url.startswith("https"):
        return True
    return False


def exploit_sql_injection(url):
    # Open the website in a web browser to manually exploit the SQL injection vulnerability
    webbrowser.open(url)


def exploit_xss_vulnerability(url):
    # Open the website in a web browser to manually exploit the XSS vulnerability
    webbrowser.open(url)


# Example usage with user input
if __name__ == "__main__":
    # Request website URL from the user
    website_url = input("Enter the website URL to scan: ")
    scan_website(website_url)

    # Personal Information
    name = "Viktoriia"
    title = "noob of cybersecurity"

    print("\n")
    print("#############################################")
    print(f"Script by: {name}")
    print(f"Title: {title}")
    print("#############################################")
